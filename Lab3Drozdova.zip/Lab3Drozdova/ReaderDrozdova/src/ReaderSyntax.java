public class ReaderSyntax {
    static final String[] readerToken = {"BUFFER_SIZE"};
    static final String bufferSize = "BUFFER_SIZE";
}
