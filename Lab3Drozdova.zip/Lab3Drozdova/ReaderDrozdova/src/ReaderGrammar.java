import ru.spbstu.pipeline.BaseGrammar;

public class ReaderGrammar extends BaseGrammar {
    ReaderGrammar(String[] tokens) {
        super(tokens);
    }
}
