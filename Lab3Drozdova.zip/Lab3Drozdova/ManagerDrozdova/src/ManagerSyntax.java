public class ManagerSyntax {
    static final String[] managerTokens = {"INPUT_FILE", "OUTPUT_FILE", "COUNT_WORKERS"};
    static final String input = "INPUT_FILE";
    static final String output = "OUTPUT_FILE";
    static final String countWorker = "COUNT_WORKERS";
    static final String worker = "WORKER";
    static final String config = "CONFIG";
}
