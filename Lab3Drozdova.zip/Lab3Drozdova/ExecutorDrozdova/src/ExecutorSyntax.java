public class ExecutorSyntax {
    static final  String[] executorToken = {"COMPRESSION", "RECOVERY", "LENGTH_SEQUENCE"};
    static final String lengthSequence = "LENGTH_SEQUENCE";
    static final String compression = "COMPRESSION";
    static final String recovery = "RECOVERY";
}
