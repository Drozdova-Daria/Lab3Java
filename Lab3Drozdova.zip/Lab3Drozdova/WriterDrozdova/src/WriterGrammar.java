import ru.spbstu.pipeline.BaseGrammar;

public class WriterGrammar extends BaseGrammar {
    WriterGrammar(String[] tokens) {
        super(tokens);
    }
}
