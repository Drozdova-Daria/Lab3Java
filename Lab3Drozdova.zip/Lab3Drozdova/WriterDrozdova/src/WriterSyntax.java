public class WriterSyntax {
    static final String[] writerToken = {"BUFFER_SIZE"};
    static final String bufferSize = "BUFFER_SIZE";
}
